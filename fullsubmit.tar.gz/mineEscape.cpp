// Project Identifier: 19034C8F3B1196BF8E0C6E1C0F973D2FD550B88F

#include <getopt.h>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <deque>
#include <queue>

using namespace std;

class MineEscape {
    private:

        bool median_mode  = false;
        bool stats_mode   = false;
        int  stats_N;
        bool verbose_mode = false;

        char input_type = '0';
        string buffer;
        int matrix_size;
        int srow;
        int scol;

        int cleared = 0;
        int total_rubble = 0;

        class Tile {
            private:
                int rubble;
                bool discovered = false;
            
            public:
                Tile() : rubble(0) {} //for resize
                
                Tile(int r) : rubble(r) {}

                int getRubbleMap() {
                    return rubble;
                }

                bool isDiscovered() {
                    return discovered;
                }

                void clearRubble() {
                    rubble = 0;
                }

                void discover() {
                    discovered = true;
                }

        };
        vector<vector<Tile>> Map;

        class ProxTile {
            private:
                int rubble;
                int row;
                int col;

            public:

                class PQComp {
                    public:

                    bool operator() (const ProxTile & lhs, const ProxTile & rhs) const {
                        if (lhs.rubble > rhs.rubble) {
                            return true;
                        }
                        else if (lhs.rubble == rhs.rubble) {
                            if (lhs.col > rhs.col) {
                                return true;
                            }
                            else if (lhs.col == rhs.col) {
                                return lhs.row > rhs.row;
                            }
                        }
                        return false;
                    }
                };

                ProxTile(int r, int row, int col) : 
                rubble(r), row(row), col(col)
                {}

                int getRubble() const {
                    return rubble;
                }

                int getRow() const {
                    return row;
                }

                int getCol() const {
                    return col;
                }
                
        };


        void createMap() {
            int current_rubble;
            Map.resize(matrix_size, vector<Tile>(matrix_size));

            for (int row = 0; row < matrix_size; row++) {
                for (int col = 0; col < matrix_size; col++) {
                    cin >> current_rubble;
                    Map[row][col] = Tile(current_rubble);
                }
            }
        }

    priority_queue<ProxTile, vector<ProxTile>, ProxTile::PQComp> pq;
    vector<vector<int>> stats_vec;
        
    public:

    // mine() : {};

    void GetOptions(int argc, char *argv[])
    {
        int choice;
        int index = 0;
        option long_options[] = {
            {"stats"  , required_argument, nullptr, 's'},
            {"median" , no_argument      , nullptr, 'm'},
            {"verbose", no_argument      , nullptr, 'v'},
            {"help"   , no_argument      , nullptr, 'h'},
            {nullptr, 0, nullptr, '\0'},
        }; // long_options[]

        while ((choice = getopt_long(argc, argv, "s:mvh", long_options, &index)) != -1)
        {
            switch (choice)
            {
            case 'h':
                //printHelp();
                exit(0);

            case 'm':
            {
                median_mode = true;
                break;
            }

            case 's':
            {
                
                stats_mode = true;
                stats_N = atoi(optarg);
                stats_vec.reserve(stats_N);
                break;
            }

            case 'v':
            {
                verbose_mode = true;
                break;
            }

            default:
                cerr << "Error: Unknown command line option" << endl;
                exit(1);
            } // switch ..choice
        }
    }
    
    void readMine() {
        cin >> input_type;
        cin >> buffer;
        cin >> matrix_size;
        cin >> buffer;
        cin >> srow >> scol;

        if (input_type != 'M' && input_type != 'R') {
            cerr << "Error: Invalid input mode" << endl;
            exit(1);
        }
        else if (srow >= matrix_size || srow < 0) {
            cerr << "Error: Invalid starting row" << endl;
            exit(1);
        }
        else if (scol >= matrix_size || scol < 0) {
            cerr << "Error: Invalid starting column" << endl;
            exit(1);
        }
    
        createMap();
    }

    void escape() {
        priority_queue<ProxTile, vector<ProxTile>, ProxTile::PQComp> TNTpq;

        Tile& start = Map[srow][scol];
        pq.push(ProxTile(start.getRubbleMap(),srow,scol));
        start.discover();

        int row;
        int col;
        int rubble;

        while (!pq.empty()) {
            const ProxTile& next = pq.top();
            row = next.getRow(); //alternative solution
            col = next.getCol();
            rubble = next.getRubble();
            if (rubble != -1) {
                if (rubble != 0) {
                    cleared++;
                    total_rubble += rubble;
                    Map[row][col].clearRubble();
                    if (verbose_mode) {
                        cout << "Cleared: " << rubble << " at [" << row << "," << col << "]\n";
                    }
                    if (stats_mode) {
                        stats_vec.emplace_back(vector<int>{rubble,row,col});
                    }
                }
                if (row == matrix_size-1 || row == 0 ||
                    col == matrix_size-1 || col == 0) {
                    break;
                }

                pq.pop();
                // pushProximal(row, col);
                        Tile& N = Map[row-1][col];
                        Tile& E = Map[row][col+1];
                        Tile& S = Map[row+1][col];
                        Tile& W = Map[row][col-1];
                        
                        if (!N.isDiscovered()) {
                            N.discover();
                            pq.push(ProxTile(N.getRubbleMap(),row-1,col));
                        }
                        if (!E.isDiscovered()) {
                            E.discover();
                            pq.push(ProxTile(E.getRubbleMap(),row,col+1));
                        }
                        if (!S.isDiscovered()) {
                            S.discover();
                            pq.push(ProxTile(S.getRubbleMap(),row+1,col));
                        }
                        if (!W.isDiscovered()) {
                            W.discover();
                            pq.push(ProxTile(W.getRubbleMap(),row,col-1));
                        }
            }
            else {
                TNTpq.push(pq.top());
                const ProxTile& nextTNT = TNTpq.top();
                while (nextTNT.getRubble() == -1) {
                    Tile& tile = Map[row][col];
                    row = nextTNT.getRow();
                    col = nextTNT.getCol();
                    tile.discover();
                    tile.clearRubble();
                    if (verbose_mode) {
                        cout << "TNT explosion at [" << row << "," << col << "]!\n";
                    }
                        Tile& N = Map[row-1][col];
                        Tile& E = Map[row][col+1];
                        Tile& S = Map[row+1][col];
                        Tile& W = Map[row][col-1];
                        
                        TNTpq.pop();

                        if (N.getRubbleMap() != 0) {
                            TNTpq.push(ProxTile(N.getRubbleMap(), row-1, col));
                        }
                        if (E.getRubbleMap() != 0) {
                            TNTpq.push(ProxTile(E.getRubbleMap(), row, col+1));
                        }
                        if (S.getRubbleMap() != 0) {
                            TNTpq.push(ProxTile(S.getRubbleMap(), row+1, col));
                        }
                        if (W.getRubbleMap() != 0) {
                            TNTpq.push(ProxTile(W.getRubbleMap(), row, col-1));
                        }
                }

                while (!TNTpq.empty()) {
                    Tile& tile = Map[row][col];

                    if (verbose_mode) {
                        cout << "Cleared by TNT: " << tile.getRubbleMap() << " at [" << row << "," << col << "]\n";
                    }

                    tile.clearRubble();

                    if (!tile.isDiscovered()) {
                            tile.discover();
                            pq.push(ProxTile(0,row,col));
                    }

                    TNTpq.pop();
                    //const ProxTile& nextTNT = TNTpq.top();
                    row = next.getRow();
                    col = next.getCol();
                }

            }
        }
    }

    void output() {
        cout << "Cleared " << cleared << " tiles containing " << total_rubble << " rubble and escaped." << endl;
        if (stats_mode) {
            if (int(stats_vec.size()) < stats_N) {
                stats_N = int(stats_vec.size());
            }
            cout << "First tiles cleared:\n";
            for (int i = 0; i < stats_N; i++) {
                if (stats_vec[i][0] == -1) {
                    cout << "TNT at [" << stats_vec[i][1] << "," << stats_vec[i][2] << "]\n";
                }
                else {
                    cout << stats_vec[i][0] << " at [" << stats_vec[i][1] << "," << stats_vec[i][2] << "]\n";
                }
            }

            cout << "Last tiles cleared:\n";
            for (int i = stats_N-1; i >= 0; i--) {
                if (stats_vec[i][0] == -1) {
                    cout << "TNT at [" << stats_vec[i][1] << "," << stats_vec[i][2] << "]\n";
                }
                else {
                    cout << stats_vec[i][0] << " at [" << stats_vec[i][1] << "," << stats_vec[i][2] << "]\n";
                }
            }
            
            cout << "Easiest tiles cleared:\n";
            sort(stats_vec.begin(), stats_vec.end());
            for (int i = 0; i < stats_N; i++) {
                if (stats_vec[i][0] == -1) {
                    cout << "TNT at [" << stats_vec[i][1] << "," << stats_vec[i][2] << "]\n";
                }
                else {
                    cout << stats_vec[i][0] << " at [" << stats_vec[i][1] << "," << stats_vec[i][2] << "]\n";
                }
            }

            cout << "Hardest tiles cleared:\n";
            for (int i = stats_N-1; i >= 0; i--) {
                if (stats_vec[i][0] == -1) {
                    cout << "TNT at [" << stats_vec[i][1] << "," << stats_vec[i][2] << "]\n";
                }
                else {
                    cout << stats_vec[i][0] << " at [" << stats_vec[i][1] << "," << stats_vec[i][2] << "]\n";
                }
            }
        }
    }
};

int main(int argc, char *argv[])
{
    std::ios_base::sync_with_stdio(false);
    //cout << std::fixed << std::setprecision(2);
    MineEscape object = MineEscape();
    object.GetOptions(argc, argv);
    object.readMine();
    object.escape();
    object.output();

    // std::vector<int> vec = {1, 2, 3, 4, 5};

    // // Create a reference to the first element
    // const int& first_element = vec.front();

    // // Output the value of the first element before popping
    // std::cout << "Before popping: " << first_element << std::endl;

    // // Pop the first element off the vector
    // vec.erase(vec.begin());

    // // Output the value of the first element after popping
    // std::cout << "After popping: " << first_element << std::endl;

}